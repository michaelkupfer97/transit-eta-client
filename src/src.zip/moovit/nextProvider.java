package moovit;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class nextProvider implements INextBusProvider{
    private static final String BASE_URL = "http://d2fo80vv1pnzuu.cloudfront.net/test/";
    private final HttpClient client = HttpClient.newHttpClient();
    private static final Pattern ITEM = Pattern.compile("\"stopId\"\\s*:\\s*(\\d+)\\s*,\\s*\"eta\"\\s*:\\s*(\\d+)");

    @Override
    public List<StopEta> getLineEta(String lineNumber) throws Exception {
        String url = BASE_URL + lineNumber;

        String json = httpGet(url);

        List<StopEta> result = new ArrayList<>();
        Matcher m = ITEM.matcher(json);
        while (m.find()) {
            int stopId = Integer.parseInt(m.group(1));
            long eta = Long.parseLong(m.group(2));
            result.add(new StopEta(stopId, new Date(eta)));
        }
        return result;
    }

    private String httpGet(String url) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
        //TODO add exceptions
        return res.body();
    }
}

