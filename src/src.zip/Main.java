import moovit.StopEta;
import moovit.nextProvider;

import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        nextProvider provider = new nextProvider();
        List<StopEta> etas = provider.getLineEta("11");
        if(etas.isEmpty()) System.out.println("There is no eta.");
        else{
            for (StopEta e : etas) {
                System.out.println(e);
            }
        }

    }
}