package moovit;

import moovit.entitys.StopEta;

import java.util.List;

public interface INextBusProvider {
    List<StopEta> getLineEta(String lineNumber)throws Exception;
}
