package moovit;

import moovit.entitys.StopEta;

import java.util.List;

public interface INextBusManager {
    List<StopEta> getLineEta(int providerId, String lineNumber);

}
